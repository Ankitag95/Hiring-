package com.ncr.skill;
/*package com.ncr.ToDo;

import javax.sql.DataSource;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DataSourceTest {
     
    //@Autowired
    private DataSource dataSource;
     
    //@Test
    public void givenTomcatConnectionPoolInstance_whenCheckedPoolClassName_thenCorrect() {
        System.out.println(dataSource.getClass().getName());
    }
}*/