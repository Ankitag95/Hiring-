package com.ncr.hiring.exception;

import java.util.Date;

public class ErrorDetails {

	public ErrorDetails(Date date, String string, String string2) {
		// TODO Auto-generated constructor stub
	}

}
