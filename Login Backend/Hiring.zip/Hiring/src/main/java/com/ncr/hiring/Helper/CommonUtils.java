package com.ncr.hiring.Helper;

public class CommonUtils {
	public static String QLID;
}
